# 
# Discrete Fourier transform (Python)
# by Project Nayuki, 2017. Public domain.
# https://www.nayuki.io/page/how-to-implement-the-discrete-fourier-transform
# 


# 
# Computes the discrete Fourier transform (DFT) of the given complex vector.
# 'input' is a sequence of numbers (integer, float, or complex).
# Returns a list of complex numbers as output, having the same length.
# 
import cmath
def compute_dft_complex(input):
    n = len(input)
    output = []
    for k in range(n):  # For each output element
        s = complex(0)
        for t in range(n):  # For each input element
            angle = 2j * cmath.pi * t * k / n
            s += input[t] * cmath.exp(-angle)
        output.append(s)
    return output


# 
# (Alternate implementation using only real numbers.)
# Computes the discrete Fourier transform (DFT) of the given complex vector.
# 'inreal' and 'inimag' are each a sequence of n floating-point numbers.
# Returns a tuple of two lists of floats - outreal and outimag, each of length n.
# 
import math
def compute_dft_real_pair(inreal, inimag, N):
    assert len(inreal) == len(inimag)
    n = len(inreal)
    outreal = []
    outimag = []
    for k in range(N):  # For each output element
        sumreal = 0.0
        sumimag = 0.0
        k_factor = 2 * math.pi * k / (N * 2)
        for t in range(n):  # For each input element
            angle =  t * k_factor
            sumreal +=  inreal[t] * math.cos(angle) + inimag[t] * math.sin(angle)
            sumimag += -inreal[t] * math.sin(angle) + inimag[t] * math.cos(angle)
        outreal.append(sumreal)
        outimag.append(sumimag)
    return (outreal, outimag)

def gen_sinus(amp: float, freq: float, phase: float, time: list):
    sinusList = []
    for t in time:
        sinusList.append(amp * math.sin(2 * math.pi * freq * t + phase))
    return sinusList

def gen_rect(amp: float, freq: float, phase: float, time: list):
    rectList = []
    for t in time:
        tmp = math.sin(2 * math.pi * freq * t + phase)
        if tmp >= 0:
            rectList.append(amp * 1)
        else: 
            rectList.append(amp * 0)
    return rectList

if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import numpy as np
    amp = 1.0
    freq = 100 # Hz
    phase = 0 # Pi
    time = 2 # s
    Fs = 3000 # Hz sample frequency
    time_vec = np.arange(0, time, 1/Fs)
    signal_list = {}
    # signal_list["sinus_vec"] = np.array(gen_sinus(amp=amp, freq=freq, phase=phase, time=time_vec))
    # signal_list["sinus_vec2"] = np.array(gen_sinus(amp=amp, freq=freq/3, phase=phase+0.5*math.pi, time=time_vec))
    signal_list["rect_vec"] = np.array(gen_rect(amp=amp, freq=freq, phase=phase, time=time_vec))

    # signal_list["tri_vec"]  = np.zeros(len(time_vec))
    # for i in range(1, len(signal_list["tri_vec"])):
    #     signal_list["tri_vec"][i] = signal_list["tri_vec"][i-1] + signal_list["rect_vec"][i]

    signal = np.zeros(len(time_vec))
    for i in signal_list:
        signal += signal_list[i]

    plt.figure()
    plt.plot(time_vec, signal)
    plt.title('Signal')
    plt.ylabel('')
    plt.xlabel('t')

    zero_list = np.zeros(len(time_vec))
    dft_real, dft_imag = compute_dft_real_pair(signal, zero_list, round(len(time_vec)/4))
    dft_abs = np.zeros(len(dft_real))
    dft_arg = np.zeros(len(dft_real))
    for i in range(len(dft_abs)):
        dft_abs[i] = math.sqrt(dft_real[i]**2 + dft_imag[i]**2)
        dft_arg[i] = math.atan2(dft_imag[i], dft_real[i])

    dftFreqList = np.linspace(0, Fs/2, len(dft_abs))
    plt.figure()
    plt.subplot(211)
    plt.plot(dftFreqList, 10.*np.log10(dft_abs))
    plt.title('sinusTest spectrum')
    plt.ylabel('Abs [dB]')
    plt.xlabel('f')
    plt.subplot(212)
    plt.plot(dftFreqList, dft_arg)
    plt.title('sinusTest phase')
    plt.ylabel('Arg')
    plt.xlabel('f')
    plt.show()
    pass
    # %%
